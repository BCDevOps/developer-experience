# JSONSchemas for the BCRegistry legal filings

This has the JSONSchema for the legal filings, as well as sample test data.

This also includes an installable python package for flask apps for working with the schemas and making validations easier within python code.

The package is stored in the common gov't PyPi repo.
