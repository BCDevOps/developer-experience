# JSONSchemas for the BCRegistry legal filings

This has the JSONSchema for the legal filings, as well as sample test data.
