__version__ = '0.3.0'


from aiohttp.pytest_plugin import *
