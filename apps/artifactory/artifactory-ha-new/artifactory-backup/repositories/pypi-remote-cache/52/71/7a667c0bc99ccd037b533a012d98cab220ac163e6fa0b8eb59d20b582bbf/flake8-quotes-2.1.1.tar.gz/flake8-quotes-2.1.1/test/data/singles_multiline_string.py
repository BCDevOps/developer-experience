s = ''' This 'should'
'not' be
'linted' '''

s = """ This 'should'
'not' be
linted 'either' """
