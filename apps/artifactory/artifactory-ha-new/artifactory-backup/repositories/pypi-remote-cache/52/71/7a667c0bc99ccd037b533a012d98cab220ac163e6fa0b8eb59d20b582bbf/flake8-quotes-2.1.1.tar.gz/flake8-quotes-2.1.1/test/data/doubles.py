this_should_be_linted = "double quote string"
this_should_be_linted = u"double quote string"
this_should_be_linted = br"double quote string"  # use b instead of u, as ur is invalid in Py3
