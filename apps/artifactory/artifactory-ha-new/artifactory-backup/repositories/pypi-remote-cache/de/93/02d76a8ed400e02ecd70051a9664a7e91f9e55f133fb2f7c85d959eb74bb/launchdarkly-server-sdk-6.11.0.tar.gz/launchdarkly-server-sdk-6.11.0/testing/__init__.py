import os

sdk_key = os.environ.get('LD_SDK_KEY')
