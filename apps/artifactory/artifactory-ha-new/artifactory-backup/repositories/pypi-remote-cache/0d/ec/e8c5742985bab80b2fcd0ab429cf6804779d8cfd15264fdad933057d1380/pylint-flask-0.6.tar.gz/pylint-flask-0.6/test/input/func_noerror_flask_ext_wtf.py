'''Ensure that pylint finds the exported methods from flask.ext.'''

from flask.ext import wtf

MYFORM = wtf.Form
