class Test(object):
    pass
