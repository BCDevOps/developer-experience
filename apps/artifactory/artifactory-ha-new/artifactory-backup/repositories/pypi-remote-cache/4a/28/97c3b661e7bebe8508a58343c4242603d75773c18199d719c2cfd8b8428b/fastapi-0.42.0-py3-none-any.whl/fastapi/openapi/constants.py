METHODS_WITH_BODY = set(("POST", "PUT", "DELETE", "PATCH"))
REF_PREFIX = "#/components/schemas/"
