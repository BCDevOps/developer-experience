flake8-blind-except
===================

A flake8 extension that checks for blind, catch-all ``except:`` statements.

Using ``except`` without explicitly specifying which exceptions to catch is generally considered bad practice, since it catches system signals like ``SIGINT``. You probably want to handle system interrupts differently than exceptions occuring in your code.

It's also usually better style to have many small ``try``-``except`` blocks catching specific exceptions instead of a giant ``try:`` block with a catch-all ``except:`` at the bottom. It's also nicer to your fellow programmers to be a bit more specific about what exceptions they can expect in specific parts of the code, and what the proper course of action is when they occur.

An example of code that will fail this check is:

.. code-block:: python

    try:
        something_scary()
    except:
        everybody_panic()

However, the following code is valid:

.. code-block:: python

    try:
        something_terrifying()
    except TerrifyingException:
        dont_panic()

Installation
------------

If you don't already have it, install ``flake8``::

    $ pip install flake8

Then, install the extension::

    $ pip install flake8-blind-except

Usage
-----

Run the following to verify that the plugin has been installed correctly::

    $ flake8 --version
    2.0 (pep8: 1.4.6, flake8-blind-except: 0.1.0, pyflakes: 0.7.3)

Now, when you run ``flake8``, the plugin will automatically be used.

When a blind except is found, ``flake8`` will output::

    B901 blind except: statement



Changes
------

0.1.1 - 2016-06-27
``````````````````
* ``pep8`` was renamed to ``pycodestyle`` in its 2.0 release. Compatibility update for this change

0.1.0 - 2014-02-07
``````````````````
* Initial release

Notes
-----

I've tested this package with flake8 2.6.2 and Python 2.7.3. It is untested (but likely compatible) with other software versions.
